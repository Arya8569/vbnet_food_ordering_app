﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GAD_MP_Form1_Home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GAD_MP_Form1_Home))
        Me.GAD_MP_Form1_Home_TitlePanel = New System.Windows.Forms.Panel()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GAD_MP_Form1_Title = New System.Windows.Forms.Label()
        Me.GAD_MP_Form1_Home_LoginPanel = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GAD_MP_Form1_Home_Login_Btn = New System.Windows.Forms.Button()
        Me.GAD_MP_Form1_Home_Login_SignUpLink = New System.Windows.Forms.Label()
        Me.GAD_MP_Form1_Home_Login_PasswordTextBox = New System.Windows.Forms.TextBox()
        Me.GAD_MP_Form1_Home_Login_UsernameTextBox = New System.Windows.Forms.TextBox()
        Me.GAD_MP_Form1_Home_Login_PasswordLabel = New System.Windows.Forms.Label()
        Me.GAD_MP_Form1_Home_Login_UsernameLabel = New System.Windows.Forms.Label()
        Me.GAD_MP_Form1_Home_EP = New System.Windows.Forms.ErrorProvider(Me.components)
        Me.GAD_MP_Form1_Home_T1 = New System.Windows.Forms.Timer(Me.components)
        Me.GAD_MP_Form1_Home_T2 = New System.Windows.Forms.Timer(Me.components)
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GAD_MP_Form1_Home_TitlePanel.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GAD_MP_Form1_Home_LoginPanel.SuspendLayout()
        CType(Me.GAD_MP_Form1_Home_EP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GAD_MP_Form1_Home_TitlePanel
        '
        Me.GAD_MP_Form1_Home_TitlePanel.BackColor = System.Drawing.Color.Coral
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.PictureBox4)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.PictureBox3)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.Button1)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.GAD_MP_Form1_Title)
        Me.GAD_MP_Form1_Home_TitlePanel.Location = New System.Drawing.Point(-3, 0)
        Me.GAD_MP_Form1_Home_TitlePanel.Name = "GAD_MP_Form1_Home_TitlePanel"
        Me.GAD_MP_Form1_Home_TitlePanel.Size = New System.Drawing.Size(1280, 150)
        Me.GAD_MP_Form1_Home_TitlePanel.TabIndex = 0
        '
        'PictureBox4
        '
        Me.PictureBox4.Location = New System.Drawing.Point(882, 21)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox4.TabIndex = 6
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Location = New System.Drawing.Point(320, 21)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox3.TabIndex = 5
        Me.PictureBox3.TabStop = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Coral
        Me.Button1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Button1.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(16, 13)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(99, 50)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'GAD_MP_Form1_Title
        '
        Me.GAD_MP_Form1_Title.AutoSize = True
        Me.GAD_MP_Form1_Title.Font = New System.Drawing.Font("Microsoft JhengHei UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GAD_MP_Form1_Title.Location = New System.Drawing.Point(287, 36)
        Me.GAD_MP_Form1_Title.Name = "GAD_MP_Form1_Title"
        Me.GAD_MP_Form1_Title.Size = New System.Drawing.Size(285, 61)
        Me.GAD_MP_Form1_Title.TabIndex = 0
        Me.GAD_MP_Form1_Title.Text = "FOOD HUB"
        '
        'GAD_MP_Form1_Home_LoginPanel
        '
        Me.GAD_MP_Form1_Home_LoginPanel.BackColor = System.Drawing.Color.Coral
        Me.GAD_MP_Form1_Home_LoginPanel.Controls.Add(Me.Label1)
        Me.GAD_MP_Form1_Home_LoginPanel.Controls.Add(Me.GAD_MP_Form1_Home_Login_Btn)
        Me.GAD_MP_Form1_Home_LoginPanel.Controls.Add(Me.GAD_MP_Form1_Home_Login_SignUpLink)
        Me.GAD_MP_Form1_Home_LoginPanel.Controls.Add(Me.GAD_MP_Form1_Home_Login_PasswordTextBox)
        Me.GAD_MP_Form1_Home_LoginPanel.Controls.Add(Me.GAD_MP_Form1_Home_Login_UsernameTextBox)
        Me.GAD_MP_Form1_Home_LoginPanel.Controls.Add(Me.GAD_MP_Form1_Home_Login_PasswordLabel)
        Me.GAD_MP_Form1_Home_LoginPanel.Controls.Add(Me.GAD_MP_Form1_Home_Login_UsernameLabel)
        Me.GAD_MP_Form1_Home_LoginPanel.Location = New System.Drawing.Point(450, 172)
        Me.GAD_MP_Form1_Home_LoginPanel.Name = "GAD_MP_Form1_Home_LoginPanel"
        Me.GAD_MP_Form1_Home_LoginPanel.Size = New System.Drawing.Size(360, 500)
        Me.GAD_MP_Form1_Home_LoginPanel.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft JhengHei", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(92, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(179, 40)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Login Now"
        '
        'GAD_MP_Form1_Home_Login_Btn
        '
        Me.GAD_MP_Form1_Home_Login_Btn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GAD_MP_Form1_Home_Login_Btn.Font = New System.Drawing.Font("Microsoft JhengHei UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GAD_MP_Form1_Home_Login_Btn.Location = New System.Drawing.Point(99, 381)
        Me.GAD_MP_Form1_Home_Login_Btn.Name = "GAD_MP_Form1_Home_Login_Btn"
        Me.GAD_MP_Form1_Home_Login_Btn.Size = New System.Drawing.Size(171, 43)
        Me.GAD_MP_Form1_Home_Login_Btn.TabIndex = 3
        Me.GAD_MP_Form1_Home_Login_Btn.Text = "Log In"
        Me.GAD_MP_Form1_Home_Login_Btn.UseVisualStyleBackColor = True
        '
        'GAD_MP_Form1_Home_Login_SignUpLink
        '
        Me.GAD_MP_Form1_Home_Login_SignUpLink.AutoSize = True
        Me.GAD_MP_Form1_Home_Login_SignUpLink.Cursor = System.Windows.Forms.Cursors.Hand
        Me.GAD_MP_Form1_Home_Login_SignUpLink.Font = New System.Drawing.Font("Microsoft JhengHei UI", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GAD_MP_Form1_Home_Login_SignUpLink.ForeColor = System.Drawing.Color.MediumBlue
        Me.GAD_MP_Form1_Home_Login_SignUpLink.Location = New System.Drawing.Point(5, 462)
        Me.GAD_MP_Form1_Home_Login_SignUpLink.Name = "GAD_MP_Form1_Home_Login_SignUpLink"
        Me.GAD_MP_Form1_Home_Login_SignUpLink.Size = New System.Drawing.Size(352, 24)
        Me.GAD_MP_Form1_Home_Login_SignUpLink.TabIndex = 4
        Me.GAD_MP_Form1_Home_Login_SignUpLink.Text = "Don't have an account? Sign-Up Now!"
        '
        'GAD_MP_Form1_Home_Login_PasswordTextBox
        '
        Me.GAD_MP_Form1_Home_Login_PasswordTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GAD_MP_Form1_Home_Login_PasswordTextBox.Location = New System.Drawing.Point(60, 318)
        Me.GAD_MP_Form1_Home_Login_PasswordTextBox.Name = "GAD_MP_Form1_Home_Login_PasswordTextBox"
        Me.GAD_MP_Form1_Home_Login_PasswordTextBox.Size = New System.Drawing.Size(250, 29)
        Me.GAD_MP_Form1_Home_Login_PasswordTextBox.TabIndex = 2
        Me.GAD_MP_Form1_Home_Login_PasswordTextBox.UseSystemPasswordChar = True
        '
        'GAD_MP_Form1_Home_Login_UsernameTextBox
        '
        Me.GAD_MP_Form1_Home_Login_UsernameTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GAD_MP_Form1_Home_Login_UsernameTextBox.Location = New System.Drawing.Point(60, 191)
        Me.GAD_MP_Form1_Home_Login_UsernameTextBox.Name = "GAD_MP_Form1_Home_Login_UsernameTextBox"
        Me.GAD_MP_Form1_Home_Login_UsernameTextBox.Size = New System.Drawing.Size(250, 29)
        Me.GAD_MP_Form1_Home_Login_UsernameTextBox.TabIndex = 1
        '
        'GAD_MP_Form1_Home_Login_PasswordLabel
        '
        Me.GAD_MP_Form1_Home_Login_PasswordLabel.AutoSize = True
        Me.GAD_MP_Form1_Home_Login_PasswordLabel.Font = New System.Drawing.Font("Microsoft JhengHei UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GAD_MP_Form1_Home_Login_PasswordLabel.Location = New System.Drawing.Point(93, 264)
        Me.GAD_MP_Form1_Home_Login_PasswordLabel.Name = "GAD_MP_Form1_Home_Login_PasswordLabel"
        Me.GAD_MP_Form1_Home_Login_PasswordLabel.Size = New System.Drawing.Size(169, 26)
        Me.GAD_MP_Form1_Home_Login_PasswordLabel.TabIndex = 1
        Me.GAD_MP_Form1_Home_Login_PasswordLabel.Text = "Enter Password:"
        '
        'GAD_MP_Form1_Home_Login_UsernameLabel
        '
        Me.GAD_MP_Form1_Home_Login_UsernameLabel.AutoSize = True
        Me.GAD_MP_Form1_Home_Login_UsernameLabel.Font = New System.Drawing.Font("Microsoft JhengHei UI", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GAD_MP_Form1_Home_Login_UsernameLabel.Location = New System.Drawing.Point(93, 132)
        Me.GAD_MP_Form1_Home_Login_UsernameLabel.Name = "GAD_MP_Form1_Home_Login_UsernameLabel"
        Me.GAD_MP_Form1_Home_Login_UsernameLabel.Size = New System.Drawing.Size(176, 26)
        Me.GAD_MP_Form1_Home_Login_UsernameLabel.TabIndex = 0
        Me.GAD_MP_Form1_Home_Login_UsernameLabel.Text = "Enter Username:"
        '
        'GAD_MP_Form1_Home_EP
        '
        Me.GAD_MP_Form1_Home_EP.ContainerControl = Me
        '
        'GAD_MP_Form1_Home_T1
        '
        Me.GAD_MP_Form1_Home_T1.Interval = 1000
        '
        'GAD_MP_Form1_Home_T2
        '
        Me.GAD_MP_Form1_Home_T2.Interval = 1000
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.GAD_MP_1.My.Resources.Resources.LoginSignImg6
        Me.PictureBox2.Location = New System.Drawing.Point(67, 196)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(350, 347)
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.GAD_MP_1.My.Resources.Resources.GAD_MP_Form1_Login_Burger
        Me.PictureBox1.Location = New System.Drawing.Point(879, 259)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(373, 360)
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'Timer1
        '
        Me.Timer1.Interval = 500
        '
        'GAD_MP_Form1_Home
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1264, 681)
        Me.Controls.Add(Me.GAD_MP_Form1_Home_LoginPanel)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GAD_MP_Form1_Home_TitlePanel)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "GAD_MP_Form1_Home"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.GAD_MP_Form1_Home_TitlePanel.ResumeLayout(False)
        Me.GAD_MP_Form1_Home_TitlePanel.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GAD_MP_Form1_Home_LoginPanel.ResumeLayout(False)
        Me.GAD_MP_Form1_Home_LoginPanel.PerformLayout()
        CType(Me.GAD_MP_Form1_Home_EP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GAD_MP_Form1_Home_TitlePanel As System.Windows.Forms.Panel
    Friend WithEvents GAD_MP_Form1_Title As System.Windows.Forms.Label
    Friend WithEvents GAD_MP_Form1_Home_LoginPanel As System.Windows.Forms.Panel
    Friend WithEvents GAD_MP_Form1_Home_Login_UsernameLabel As System.Windows.Forms.Label
    Friend WithEvents GAD_MP_Form1_Home_Login_PasswordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GAD_MP_Form1_Home_Login_UsernameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GAD_MP_Form1_Home_Login_PasswordLabel As System.Windows.Forms.Label
    Friend WithEvents GAD_MP_Form1_Home_Login_SignUpLink As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents GAD_MP_Form1_Home_Login_Btn As System.Windows.Forms.Button
    Friend WithEvents GAD_MP_Form1_Home_EP As System.Windows.Forms.ErrorProvider
    Friend WithEvents GAD_MP_Form1_Home_T1 As System.Windows.Forms.Timer
    Friend WithEvents GAD_MP_Form1_Home_T2 As System.Windows.Forms.Timer
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox

End Class
