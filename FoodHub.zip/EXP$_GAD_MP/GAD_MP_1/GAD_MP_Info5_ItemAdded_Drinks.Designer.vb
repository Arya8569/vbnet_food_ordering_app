﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GAD_MP_Info5_ItemAdded_Drinks
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GAD_MP_Info5_ItemAdded_Drinks))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Cart_Panel_Water = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.Cart_Panel_Grape = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.Cart_Panel_Orange = New System.Windows.Forms.Panel()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.Cart_Panel_Coolberg = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.PictureBox17 = New System.Windows.Forms.PictureBox()
        Me.Cart_Panel_Mango = New System.Windows.Forms.Panel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.Cart_Panel_WaterMelon = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.Cart_Panel_Mojito = New System.Windows.Forms.Panel()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.Cart_Panel_Red = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Cart_Panel_Water.SuspendLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Cart_Panel_Grape.SuspendLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Cart_Panel_Orange.SuspendLayout()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Cart_Panel_Coolberg.SuspendLayout()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Cart_Panel_Mango.SuspendLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Cart_Panel_WaterMelon.SuspendLayout()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Cart_Panel_Mojito.SuspendLayout()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Cart_Panel_Red.SuspendLayout()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Coral
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(0, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(160, 263)
        Me.Panel1.TabIndex = 13
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.GAD_MP_1.My.Resources.Resources.drinksV1
        Me.PictureBox2.Location = New System.Drawing.Point(17, 133)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox2.TabIndex = 83
        Me.PictureBox2.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(12, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(125, 26)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "FOOD HUB"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 63)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(198, 27)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Item added to Cart"
        '
        'Cart_Panel_Water
        '
        Me.Cart_Panel_Water.Controls.Add(Me.Label10)
        Me.Cart_Panel_Water.Controls.Add(Me.Label9)
        Me.Cart_Panel_Water.Controls.Add(Me.PictureBox11)
        Me.Cart_Panel_Water.Location = New System.Drawing.Point(170, 10)
        Me.Cart_Panel_Water.Name = "Cart_Panel_Water"
        Me.Cart_Panel_Water.Size = New System.Drawing.Size(200, 225)
        Me.Cart_Panel_Water.TabIndex = 68
        Me.Cart_Panel_Water.Visible = False
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 183)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(34, 13)
        Me.Label10.TabIndex = 66
        Me.Label10.Text = "$0.99"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(0, 161)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(73, 13)
        Me.Label9.TabIndex = 65
        Me.Label9.Text = "Mineral Water"
        '
        'PictureBox11
        '
        Me.PictureBox11.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox11.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox11.Image = Global.GAD_MP_1.My.Resources.Resources.water1
        Me.PictureBox11.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox11.TabIndex = 64
        Me.PictureBox11.TabStop = False
        '
        'Cart_Panel_Grape
        '
        Me.Cart_Panel_Grape.Controls.Add(Me.Label12)
        Me.Cart_Panel_Grape.Controls.Add(Me.Label11)
        Me.Cart_Panel_Grape.Controls.Add(Me.PictureBox12)
        Me.Cart_Panel_Grape.Location = New System.Drawing.Point(170, 10)
        Me.Cart_Panel_Grape.Name = "Cart_Panel_Grape"
        Me.Cart_Panel_Grape.Size = New System.Drawing.Size(200, 225)
        Me.Cart_Panel_Grape.TabIndex = 69
        Me.Cart_Panel_Grape.Visible = False
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(0, 187)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(34, 13)
        Me.Label12.TabIndex = 73
        Me.Label12.Text = "$4.99"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(0, 157)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(64, 13)
        Me.Label11.TabIndex = 72
        Me.Label11.Text = "Grape Wine"
        '
        'PictureBox12
        '
        Me.PictureBox12.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox12.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox12.Image = Global.GAD_MP_1.My.Resources.Resources.grapevineog1
        Me.PictureBox12.Location = New System.Drawing.Point(3, 0)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox12.TabIndex = 71
        Me.PictureBox12.TabStop = False
        '
        'Cart_Panel_Orange
        '
        Me.Cart_Panel_Orange.Controls.Add(Me.Label14)
        Me.Cart_Panel_Orange.Controls.Add(Me.Label13)
        Me.Cart_Panel_Orange.Controls.Add(Me.PictureBox18)
        Me.Cart_Panel_Orange.Location = New System.Drawing.Point(170, 10)
        Me.Cart_Panel_Orange.Name = "Cart_Panel_Orange"
        Me.Cart_Panel_Orange.Size = New System.Drawing.Size(200, 225)
        Me.Cart_Panel_Orange.TabIndex = 70
        Me.Cart_Panel_Orange.Visible = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(0, 187)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(34, 13)
        Me.Label14.TabIndex = 72
        Me.Label14.Text = "$6.99"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(0, 157)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(99, 13)
        Me.Label13.TabIndex = 71
        Me.Label13.Text = "Fresh Orange Juice"
        '
        'PictureBox18
        '
        Me.PictureBox18.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox18.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox18.Image = Global.GAD_MP_1.My.Resources.Resources.orangejuice1
        Me.PictureBox18.Location = New System.Drawing.Point(3, 0)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox18.TabIndex = 70
        Me.PictureBox18.TabStop = False
        '
        'Cart_Panel_Coolberg
        '
        Me.Cart_Panel_Coolberg.Controls.Add(Me.Label16)
        Me.Cart_Panel_Coolberg.Controls.Add(Me.Label15)
        Me.Cart_Panel_Coolberg.Controls.Add(Me.PictureBox17)
        Me.Cart_Panel_Coolberg.Location = New System.Drawing.Point(170, 10)
        Me.Cart_Panel_Coolberg.Name = "Cart_Panel_Coolberg"
        Me.Cart_Panel_Coolberg.Size = New System.Drawing.Size(200, 225)
        Me.Cart_Panel_Coolberg.TabIndex = 71
        Me.Cart_Panel_Coolberg.Visible = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(0, 187)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(34, 13)
        Me.Label16.TabIndex = 67
        Me.Label16.Text = "$3.49"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(0, 157)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(83, 13)
        Me.Label15.TabIndex = 66
        Me.Label15.Text = "Chilled Coolberg"
        '
        'PictureBox17
        '
        Me.PictureBox17.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox17.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox17.Image = Global.GAD_MP_1.My.Resources.Resources.coolberg1
        Me.PictureBox17.Location = New System.Drawing.Point(3, 0)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox17.TabIndex = 65
        Me.PictureBox17.TabStop = False
        '
        'Cart_Panel_Mango
        '
        Me.Cart_Panel_Mango.Controls.Add(Me.Label17)
        Me.Cart_Panel_Mango.Controls.Add(Me.Label18)
        Me.Cart_Panel_Mango.Controls.Add(Me.PictureBox13)
        Me.Cart_Panel_Mango.Location = New System.Drawing.Point(170, 10)
        Me.Cart_Panel_Mango.Name = "Cart_Panel_Mango"
        Me.Cart_Panel_Mango.Size = New System.Drawing.Size(200, 225)
        Me.Cart_Panel_Mango.TabIndex = 75
        Me.Cart_Panel_Mango.Visible = False
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(6, 187)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(34, 13)
        Me.Label17.TabIndex = 63
        Me.Label17.Text = "$9.99"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(0, 161)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(115, 13)
        Me.Label18.TabIndex = 62
        Me.Label18.Text = "Alphanso Mango Juice"
        '
        'PictureBox13
        '
        Me.PictureBox13.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox13.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox13.Image = Global.GAD_MP_1.My.Resources.Resources.maza1
        Me.PictureBox13.Location = New System.Drawing.Point(0, 1)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox13.TabIndex = 61
        Me.PictureBox13.TabStop = False
        '
        'Cart_Panel_WaterMelon
        '
        Me.Cart_Panel_WaterMelon.Controls.Add(Me.Label19)
        Me.Cart_Panel_WaterMelon.Controls.Add(Me.Label20)
        Me.Cart_Panel_WaterMelon.Controls.Add(Me.PictureBox14)
        Me.Cart_Panel_WaterMelon.Location = New System.Drawing.Point(170, 10)
        Me.Cart_Panel_WaterMelon.Name = "Cart_Panel_WaterMelon"
        Me.Cart_Panel_WaterMelon.Size = New System.Drawing.Size(200, 225)
        Me.Cart_Panel_WaterMelon.TabIndex = 76
        Me.Cart_Panel_WaterMelon.Visible = False
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(0, 191)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(34, 13)
        Me.Label19.TabIndex = 64
        Me.Label19.Text = "$6.49"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(0, 161)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(94, 13)
        Me.Label20.TabIndex = 63
        Me.Label20.Text = "Watermellon Juice"
        '
        'PictureBox14
        '
        Me.PictureBox14.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox14.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox14.Image = Global.GAD_MP_1.My.Resources.Resources.watermellon1
        Me.PictureBox14.Location = New System.Drawing.Point(3, 0)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox14.TabIndex = 62
        Me.PictureBox14.TabStop = False
        '
        'Cart_Panel_Mojito
        '
        Me.Cart_Panel_Mojito.Controls.Add(Me.Label21)
        Me.Cart_Panel_Mojito.Controls.Add(Me.Label22)
        Me.Cart_Panel_Mojito.Controls.Add(Me.PictureBox16)
        Me.Cart_Panel_Mojito.Location = New System.Drawing.Point(170, 10)
        Me.Cart_Panel_Mojito.Name = "Cart_Panel_Mojito"
        Me.Cart_Panel_Mojito.Size = New System.Drawing.Size(200, 225)
        Me.Cart_Panel_Mojito.TabIndex = 77
        Me.Cart_Panel_Mojito.Visible = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(6, 191)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(34, 13)
        Me.Label21.TabIndex = 65
        Me.Label21.Text = "$5.99"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(6, 161)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(89, 13)
        Me.Label22.TabIndex = 64
        Me.Label22.Text = "Refreshing Mojito"
        '
        'PictureBox16
        '
        Me.PictureBox16.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox16.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox16.Image = Global.GAD_MP_1.My.Resources.Resources.mojito1
        Me.PictureBox16.Location = New System.Drawing.Point(3, 0)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox16.TabIndex = 63
        Me.PictureBox16.TabStop = False
        '
        'Cart_Panel_Red
        '
        Me.Cart_Panel_Red.Controls.Add(Me.Label23)
        Me.Cart_Panel_Red.Controls.Add(Me.Label24)
        Me.Cart_Panel_Red.Controls.Add(Me.PictureBox15)
        Me.Cart_Panel_Red.Location = New System.Drawing.Point(170, 10)
        Me.Cart_Panel_Red.Name = "Cart_Panel_Red"
        Me.Cart_Panel_Red.Size = New System.Drawing.Size(200, 225)
        Me.Cart_Panel_Red.TabIndex = 78
        Me.Cart_Panel_Red.Visible = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(0, 191)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(40, 13)
        Me.Label23.TabIndex = 66
        Me.Label23.Text = "$10.99"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(0, 161)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(88, 13)
        Me.Label24.TabIndex = 65
        Me.Label24.Text = "Divine Red Wine"
        '
        'PictureBox15
        '
        Me.PictureBox15.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox15.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox15.Image = Global.GAD_MP_1.My.Resources.Resources.redvineog2
        Me.PictureBox15.Location = New System.Drawing.Point(3, 0)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox15.TabIndex = 64
        Me.PictureBox15.TabStop = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Coral
        Me.Button1.Font = New System.Drawing.Font("Microsoft JhengHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(402, 214)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(70, 35)
        Me.Button1.TabIndex = 81
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.GAD_MP_1.My.Resources.Resources.shopping1
        Me.PictureBox1.Location = New System.Drawing.Point(376, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(106, 175)
        Me.PictureBox1.TabIndex = 80
        Me.PictureBox1.TabStop = False
        '
        'Timer1
        '
        '
        'GAD_MP_Info5_ItemAdded_Drinks
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(484, 261)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Cart_Panel_Orange)
        Me.Controls.Add(Me.Cart_Panel_Grape)
        Me.Controls.Add(Me.Cart_Panel_Water)
        Me.Controls.Add(Me.Cart_Panel_Red)
        Me.Controls.Add(Me.Cart_Panel_Mojito)
        Me.Controls.Add(Me.Cart_Panel_WaterMelon)
        Me.Controls.Add(Me.Cart_Panel_Mango)
        Me.Controls.Add(Me.Cart_Panel_Coolberg)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "GAD_MP_Info5_ItemAdded_Drinks"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GAD_MP_CART_DRINKS"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Cart_Panel_Water.ResumeLayout(False)
        Me.Cart_Panel_Water.PerformLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Cart_Panel_Grape.ResumeLayout(False)
        Me.Cart_Panel_Grape.PerformLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Cart_Panel_Orange.ResumeLayout(False)
        Me.Cart_Panel_Orange.PerformLayout()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Cart_Panel_Coolberg.ResumeLayout(False)
        Me.Cart_Panel_Coolberg.PerformLayout()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Cart_Panel_Mango.ResumeLayout(False)
        Me.Cart_Panel_Mango.PerformLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Cart_Panel_WaterMelon.ResumeLayout(False)
        Me.Cart_Panel_WaterMelon.PerformLayout()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Cart_Panel_Mojito.ResumeLayout(False)
        Me.Cart_Panel_Mojito.PerformLayout()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Cart_Panel_Red.ResumeLayout(False)
        Me.Cart_Panel_Red.PerformLayout()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Cart_Panel_Water As System.Windows.Forms.Panel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents Cart_Panel_Grape As System.Windows.Forms.Panel
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents Cart_Panel_Orange As System.Windows.Forms.Panel
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents PictureBox18 As System.Windows.Forms.PictureBox
    Friend WithEvents Cart_Panel_Coolberg As System.Windows.Forms.Panel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents PictureBox17 As System.Windows.Forms.PictureBox
    Friend WithEvents Cart_Panel_Mango As System.Windows.Forms.Panel
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
    Friend WithEvents Cart_Panel_WaterMelon As System.Windows.Forms.Panel
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents PictureBox14 As System.Windows.Forms.PictureBox
    Friend WithEvents Cart_Panel_Mojito As System.Windows.Forms.Panel
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents PictureBox16 As System.Windows.Forms.PictureBox
    Friend WithEvents Cart_Panel_Red As System.Windows.Forms.Panel
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents PictureBox15 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
