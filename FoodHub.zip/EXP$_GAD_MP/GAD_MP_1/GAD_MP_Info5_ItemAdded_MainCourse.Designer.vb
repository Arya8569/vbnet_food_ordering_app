﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GAD_MP_Info5_ItemAdded_MainCourse
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GAD_MP_Info5_ItemAdded_MainCourse))
        Me.Label21 = New System.Windows.Forms.Label()
        Me.GAD_MP_ItemAdded_ChickenTikkaMasala = New System.Windows.Forms.Panel()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.GAD_MP_ItemAdded_GrilledChicken = New System.Windows.Forms.Panel()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.GAD_MP_ItemAdded_SpaghettiBolognese = New System.Windows.Forms.Panel()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.GAD_MP_ItemAdded_BeefSteak = New System.Windows.Forms.Panel()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GAD_MP_ItemAdded_FishFillet = New System.Windows.Forms.Panel()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.PictureBox17 = New System.Windows.Forms.PictureBox()
        Me.GAD_MP_ItemAdded_ShrimpScampi = New System.Windows.Forms.Panel()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.GAD_MP_ItemAdded_TunaSushi = New System.Windows.Forms.Panel()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.GAD_MP_ItemAdded_BeefRibs = New System.Windows.Forms.Panel()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.GAD_MP_ItemAdded_ChickenTikkaMasala.SuspendLayout()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GAD_MP_ItemAdded_GrilledChicken.SuspendLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GAD_MP_ItemAdded_SpaghettiBolognese.SuspendLayout()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GAD_MP_ItemAdded_BeefSteak.SuspendLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GAD_MP_ItemAdded_FishFillet.SuspendLayout()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GAD_MP_ItemAdded_ShrimpScampi.SuspendLayout()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GAD_MP_ItemAdded_TunaSushi.SuspendLayout()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GAD_MP_ItemAdded_BeefRibs.SuspendLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(12, 192)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(40, 13)
        Me.Label21.TabIndex = 65
        Me.Label21.Text = "$39.99"
        '
        'GAD_MP_ItemAdded_ChickenTikkaMasala
        '
        Me.GAD_MP_ItemAdded_ChickenTikkaMasala.Controls.Add(Me.Label23)
        Me.GAD_MP_ItemAdded_ChickenTikkaMasala.Controls.Add(Me.Label24)
        Me.GAD_MP_ItemAdded_ChickenTikkaMasala.Controls.Add(Me.PictureBox15)
        Me.GAD_MP_ItemAdded_ChickenTikkaMasala.Location = New System.Drawing.Point(150, 10)
        Me.GAD_MP_ItemAdded_ChickenTikkaMasala.Name = "GAD_MP_ItemAdded_ChickenTikkaMasala"
        Me.GAD_MP_ItemAdded_ChickenTikkaMasala.Size = New System.Drawing.Size(200, 250)
        Me.GAD_MP_ItemAdded_ChickenTikkaMasala.TabIndex = 84
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(15, 193)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(40, 13)
        Me.Label23.TabIndex = 66
        Me.Label23.Text = "$24.99"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(15, 170)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(113, 13)
        Me.Label24.TabIndex = 65
        Me.Label24.Text = "Chicken Masala Tikka"
        '
        'PictureBox15
        '
        Me.PictureBox15.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox15.Image = Global.GAD_MP_1.My.Resources.Resources.ChickenTikkaMasala
        Me.PictureBox15.Location = New System.Drawing.Point(15, 0)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox15.TabIndex = 64
        Me.PictureBox15.TabStop = False
        '
        'GAD_MP_ItemAdded_GrilledChicken
        '
        Me.GAD_MP_ItemAdded_GrilledChicken.Controls.Add(Me.Label12)
        Me.GAD_MP_ItemAdded_GrilledChicken.Controls.Add(Me.Label11)
        Me.GAD_MP_ItemAdded_GrilledChicken.Controls.Add(Me.PictureBox12)
        Me.GAD_MP_ItemAdded_GrilledChicken.Location = New System.Drawing.Point(150, 10)
        Me.GAD_MP_ItemAdded_GrilledChicken.Name = "GAD_MP_ItemAdded_GrilledChicken"
        Me.GAD_MP_ItemAdded_GrilledChicken.Size = New System.Drawing.Size(200, 250)
        Me.GAD_MP_ItemAdded_GrilledChicken.TabIndex = 83
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(12, 192)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(40, 13)
        Me.Label12.TabIndex = 73
        Me.Label12.Text = "$39.99"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(14, 160)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(78, 13)
        Me.Label11.TabIndex = 72
        Me.Label11.Text = "Grilled Chicken"
        '
        'PictureBox12
        '
        Me.PictureBox12.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox12.Image = Global.GAD_MP_1.My.Resources.Resources.pexels_eiliv_aceron_6896080
        Me.PictureBox12.Location = New System.Drawing.Point(15, 0)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox12.TabIndex = 71
        Me.PictureBox12.TabStop = False
        '
        'GAD_MP_ItemAdded_SpaghettiBolognese
        '
        Me.GAD_MP_ItemAdded_SpaghettiBolognese.Controls.Add(Me.PictureBox18)
        Me.GAD_MP_ItemAdded_SpaghettiBolognese.Controls.Add(Me.Label14)
        Me.GAD_MP_ItemAdded_SpaghettiBolognese.Controls.Add(Me.Label13)
        Me.GAD_MP_ItemAdded_SpaghettiBolognese.Location = New System.Drawing.Point(150, 10)
        Me.GAD_MP_ItemAdded_SpaghettiBolognese.Name = "GAD_MP_ItemAdded_SpaghettiBolognese"
        Me.GAD_MP_ItemAdded_SpaghettiBolognese.Size = New System.Drawing.Size(200, 250)
        Me.GAD_MP_ItemAdded_SpaghettiBolognese.TabIndex = 89
        '
        'PictureBox18
        '
        Me.PictureBox18.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox18.Image = Global.GAD_MP_1.My.Resources.Resources.pexels_klaus_nielsen_6287525
        Me.PictureBox18.Location = New System.Drawing.Point(12, 1)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox18.TabIndex = 73
        Me.PictureBox18.TabStop = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(12, 189)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(40, 13)
        Me.Label14.TabIndex = 72
        Me.Label14.Text = "$44.99"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(12, 160)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(105, 13)
        Me.Label13.TabIndex = 71
        Me.Label13.Text = "Spaghetti Bolognese"
        '
        'GAD_MP_ItemAdded_BeefSteak
        '
        Me.GAD_MP_ItemAdded_BeefSteak.Controls.Add(Me.Label10)
        Me.GAD_MP_ItemAdded_BeefSteak.Controls.Add(Me.Label9)
        Me.GAD_MP_ItemAdded_BeefSteak.Controls.Add(Me.PictureBox11)
        Me.GAD_MP_ItemAdded_BeefSteak.Location = New System.Drawing.Point(150, 10)
        Me.GAD_MP_ItemAdded_BeefSteak.Name = "GAD_MP_ItemAdded_BeefSteak"
        Me.GAD_MP_ItemAdded_BeefSteak.Size = New System.Drawing.Size(200, 250)
        Me.GAD_MP_ItemAdded_BeefSteak.TabIndex = 90
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 187)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(40, 13)
        Me.Label10.TabIndex = 66
        Me.Label10.Text = "$54.99"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 157)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 13)
        Me.Label9.TabIndex = 65
        Me.Label9.Text = "Beef Steak"
        '
        'PictureBox11
        '
        Me.PictureBox11.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox11.Image = Global.GAD_MP_1.My.Resources.Resources.pexels_valeria_boltneva_1307658
        Me.PictureBox11.Location = New System.Drawing.Point(7, 0)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox11.TabIndex = 64
        Me.PictureBox11.TabStop = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(15, 160)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(61, 13)
        Me.Label22.TabIndex = 64
        Me.Label22.Text = "Tuna Sushi"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Coral
        Me.Panel1.Controls.Add(Me.PictureBox2)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(0, -1)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(148, 263)
        Me.Panel1.TabIndex = 80
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.GAD_MP_1.My.Resources.Resources.tableware_200px
        Me.PictureBox2.Location = New System.Drawing.Point(17, 141)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox2.TabIndex = 18
        Me.PictureBox2.TabStop = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(12, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(125, 26)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "FOOD HUB"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(18, 78)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(198, 27)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Item added to Cart"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Coral
        Me.Button1.Font = New System.Drawing.Font("Microsoft JhengHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(402, 214)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(70, 35)
        Me.Button1.TabIndex = 81
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'GAD_MP_ItemAdded_FishFillet
        '
        Me.GAD_MP_ItemAdded_FishFillet.Controls.Add(Me.Label16)
        Me.GAD_MP_ItemAdded_FishFillet.Controls.Add(Me.Label15)
        Me.GAD_MP_ItemAdded_FishFillet.Controls.Add(Me.PictureBox17)
        Me.GAD_MP_ItemAdded_FishFillet.Location = New System.Drawing.Point(150, 10)
        Me.GAD_MP_ItemAdded_FishFillet.Name = "GAD_MP_ItemAdded_FishFillet"
        Me.GAD_MP_ItemAdded_FishFillet.Size = New System.Drawing.Size(200, 250)
        Me.GAD_MP_ItemAdded_FishFillet.TabIndex = 86
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(9, 193)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(40, 13)
        Me.Label16.TabIndex = 67
        Me.Label16.Text = "$49.49"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(9, 164)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(50, 13)
        Me.Label15.TabIndex = 66
        Me.Label15.Text = "Fish Fillet"
        '
        'PictureBox17
        '
        Me.PictureBox17.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox17.Image = Global.GAD_MP_1.My.Resources.Resources.FishFillet
        Me.PictureBox17.Location = New System.Drawing.Point(15, 0)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox17.TabIndex = 65
        Me.PictureBox17.TabStop = False
        '
        'GAD_MP_ItemAdded_ShrimpScampi
        '
        Me.GAD_MP_ItemAdded_ShrimpScampi.Controls.Add(Me.Label19)
        Me.GAD_MP_ItemAdded_ShrimpScampi.Controls.Add(Me.Label20)
        Me.GAD_MP_ItemAdded_ShrimpScampi.Controls.Add(Me.PictureBox14)
        Me.GAD_MP_ItemAdded_ShrimpScampi.Location = New System.Drawing.Point(150, 10)
        Me.GAD_MP_ItemAdded_ShrimpScampi.Name = "GAD_MP_ItemAdded_ShrimpScampi"
        Me.GAD_MP_ItemAdded_ShrimpScampi.Size = New System.Drawing.Size(200, 250)
        Me.GAD_MP_ItemAdded_ShrimpScampi.TabIndex = 87
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(15, 196)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(40, 13)
        Me.Label19.TabIndex = 64
        Me.Label19.Text = "$44.49"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(15, 167)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(77, 13)
        Me.Label20.TabIndex = 63
        Me.Label20.Text = "Shrimp Scampi"
        '
        'PictureBox14
        '
        Me.PictureBox14.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox14.Image = Global.GAD_MP_1.My.Resources.Resources.ShrimpScampi
        Me.PictureBox14.Location = New System.Drawing.Point(15, 0)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox14.TabIndex = 62
        Me.PictureBox14.TabStop = False
        '
        'GAD_MP_ItemAdded_TunaSushi
        '
        Me.GAD_MP_ItemAdded_TunaSushi.Controls.Add(Me.Label21)
        Me.GAD_MP_ItemAdded_TunaSushi.Controls.Add(Me.Label22)
        Me.GAD_MP_ItemAdded_TunaSushi.Controls.Add(Me.PictureBox16)
        Me.GAD_MP_ItemAdded_TunaSushi.Location = New System.Drawing.Point(150, 10)
        Me.GAD_MP_ItemAdded_TunaSushi.Name = "GAD_MP_ItemAdded_TunaSushi"
        Me.GAD_MP_ItemAdded_TunaSushi.Size = New System.Drawing.Size(200, 250)
        Me.GAD_MP_ItemAdded_TunaSushi.TabIndex = 85
        '
        'PictureBox16
        '
        Me.PictureBox16.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox16.Image = Global.GAD_MP_1.My.Resources.Resources.TunaSushi
        Me.PictureBox16.Location = New System.Drawing.Point(15, 0)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox16.TabIndex = 63
        Me.PictureBox16.TabStop = False
        '
        'GAD_MP_ItemAdded_BeefRibs
        '
        Me.GAD_MP_ItemAdded_BeefRibs.Controls.Add(Me.Label17)
        Me.GAD_MP_ItemAdded_BeefRibs.Controls.Add(Me.Label18)
        Me.GAD_MP_ItemAdded_BeefRibs.Controls.Add(Me.PictureBox13)
        Me.GAD_MP_ItemAdded_BeefRibs.Location = New System.Drawing.Point(150, 10)
        Me.GAD_MP_ItemAdded_BeefRibs.Name = "GAD_MP_ItemAdded_BeefRibs"
        Me.GAD_MP_ItemAdded_BeefRibs.Size = New System.Drawing.Size(200, 250)
        Me.GAD_MP_ItemAdded_BeefRibs.TabIndex = 88
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(14, 186)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(40, 13)
        Me.Label17.TabIndex = 63
        Me.Label17.Text = "$49.99"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(14, 157)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(53, 13)
        Me.Label18.TabIndex = 62
        Me.Label18.Text = "Beef Ribs"
        '
        'PictureBox13
        '
        Me.PictureBox13.BackColor = System.Drawing.Color.DimGray
        Me.PictureBox13.Image = Global.GAD_MP_1.My.Resources.Resources.BeefRibs
        Me.PictureBox13.Location = New System.Drawing.Point(15, 0)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox13.TabIndex = 61
        Me.PictureBox13.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.GAD_MP_1.My.Resources.Resources.shopping1
        Me.PictureBox1.Location = New System.Drawing.Point(372, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 170)
        Me.PictureBox1.TabIndex = 82
        Me.PictureBox1.TabStop = False
        '
        'Timer1
        '
        '
        'GAD_MP_Info5_ItemAdded_MainCourse
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(484, 261)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.GAD_MP_ItemAdded_ChickenTikkaMasala)
        Me.Controls.Add(Me.GAD_MP_ItemAdded_GrilledChicken)
        Me.Controls.Add(Me.GAD_MP_ItemAdded_SpaghettiBolognese)
        Me.Controls.Add(Me.GAD_MP_ItemAdded_BeefSteak)
        Me.Controls.Add(Me.GAD_MP_ItemAdded_FishFillet)
        Me.Controls.Add(Me.GAD_MP_ItemAdded_ShrimpScampi)
        Me.Controls.Add(Me.GAD_MP_ItemAdded_TunaSushi)
        Me.Controls.Add(Me.GAD_MP_ItemAdded_BeefRibs)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "GAD_MP_Info5_ItemAdded_MainCourse"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GAD_MP_ItemAdded"
        Me.GAD_MP_ItemAdded_ChickenTikkaMasala.ResumeLayout(False)
        Me.GAD_MP_ItemAdded_ChickenTikkaMasala.PerformLayout()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GAD_MP_ItemAdded_GrilledChicken.ResumeLayout(False)
        Me.GAD_MP_ItemAdded_GrilledChicken.PerformLayout()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GAD_MP_ItemAdded_SpaghettiBolognese.ResumeLayout(False)
        Me.GAD_MP_ItemAdded_SpaghettiBolognese.PerformLayout()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GAD_MP_ItemAdded_BeefSteak.ResumeLayout(False)
        Me.GAD_MP_ItemAdded_BeefSteak.PerformLayout()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GAD_MP_ItemAdded_FishFillet.ResumeLayout(False)
        Me.GAD_MP_ItemAdded_FishFillet.PerformLayout()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GAD_MP_ItemAdded_ShrimpScampi.ResumeLayout(False)
        Me.GAD_MP_ItemAdded_ShrimpScampi.PerformLayout()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GAD_MP_ItemAdded_TunaSushi.ResumeLayout(False)
        Me.GAD_MP_ItemAdded_TunaSushi.PerformLayout()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GAD_MP_ItemAdded_BeefRibs.ResumeLayout(False)
        Me.GAD_MP_ItemAdded_BeefRibs.PerformLayout()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents GAD_MP_ItemAdded_ChickenTikkaMasala As System.Windows.Forms.Panel
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents PictureBox15 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GAD_MP_ItemAdded_GrilledChicken As System.Windows.Forms.Panel
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents PictureBox12 As System.Windows.Forms.PictureBox
    Friend WithEvents GAD_MP_ItemAdded_SpaghettiBolognese As System.Windows.Forms.Panel
    Friend WithEvents PictureBox18 As System.Windows.Forms.PictureBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents GAD_MP_ItemAdded_BeefSteak As System.Windows.Forms.Panel
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents PictureBox11 As System.Windows.Forms.PictureBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents GAD_MP_ItemAdded_FishFillet As System.Windows.Forms.Panel
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents PictureBox17 As System.Windows.Forms.PictureBox
    Friend WithEvents GAD_MP_ItemAdded_ShrimpScampi As System.Windows.Forms.Panel
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents PictureBox14 As System.Windows.Forms.PictureBox
    Friend WithEvents GAD_MP_ItemAdded_TunaSushi As System.Windows.Forms.Panel
    Friend WithEvents PictureBox16 As System.Windows.Forms.PictureBox
    Friend WithEvents GAD_MP_ItemAdded_BeefRibs As System.Windows.Forms.Panel
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents PictureBox13 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
