﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class GAD_MP_Form7_Cart
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(GAD_MP_Form7_Cart))
        Me.GAD_MP_Form1_Home_TitlePanel = New System.Windows.Forms.Panel()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.DLabel = New System.Windows.Forms.Label()
        Me.ICLabel = New System.Windows.Forms.Label()
        Me.CLabel = New System.Windows.Forms.Label()
        Me.AULabel = New System.Windows.Forms.Label()
        Me.MCLabel = New System.Windows.Forms.Label()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GAD_MP_Form1_Title = New System.Windows.Forms.Label()
        Me.ShapeContainer2 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.CartLBL1 = New System.Windows.Forms.Label()
        Me.CartLBL2 = New System.Windows.Forms.Label()
        Me.CartLBL3 = New System.Windows.Forms.Label()
        Me.CartLBL4 = New System.Windows.Forms.Label()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.ListBox4 = New System.Windows.Forms.ListBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.GAD_MP_Form1_Home_TitlePanel.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GAD_MP_Form1_Home_TitlePanel
        '
        Me.GAD_MP_Form1_Home_TitlePanel.BackColor = System.Drawing.Color.Coral
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.PictureBox3)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.DLabel)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.ICLabel)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.CLabel)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.AULabel)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.MCLabel)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.PictureBox6)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.PictureBox5)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.PictureBox4)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.PictureBox1)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.Button2)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.Button1)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.GAD_MP_Form1_Title)
        Me.GAD_MP_Form1_Home_TitlePanel.Controls.Add(Me.ShapeContainer2)
        Me.GAD_MP_Form1_Home_TitlePanel.Location = New System.Drawing.Point(-1, -2)
        Me.GAD_MP_Form1_Home_TitlePanel.Name = "GAD_MP_Form1_Home_TitlePanel"
        Me.GAD_MP_Form1_Home_TitlePanel.Size = New System.Drawing.Size(307, 684)
        Me.GAD_MP_Form1_Home_TitlePanel.TabIndex = 4
        '
        'PictureBox3
        '
        Me.PictureBox3.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox3.Image = Global.GAD_MP_1.My.Resources.Resources.user
        Me.PictureBox3.Location = New System.Drawing.Point(23, 579)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox3.TabIndex = 23
        Me.PictureBox3.TabStop = False
        '
        'DLabel
        '
        Me.DLabel.AutoSize = True
        Me.DLabel.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DLabel.Location = New System.Drawing.Point(146, 301)
        Me.DLabel.Name = "DLabel"
        Me.DLabel.Size = New System.Drawing.Size(75, 27)
        Me.DLabel.TabIndex = 22
        Me.DLabel.Text = "Drinks"
        '
        'ICLabel
        '
        Me.ICLabel.AutoSize = True
        Me.ICLabel.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ICLabel.Location = New System.Drawing.Point(146, 402)
        Me.ICLabel.Name = "ICLabel"
        Me.ICLabel.Size = New System.Drawing.Size(98, 27)
        Me.ICLabel.TabIndex = 21
        Me.ICLabel.Text = "Desserts"
        '
        'CLabel
        '
        Me.CLabel.AutoSize = True
        Me.CLabel.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CLabel.ForeColor = System.Drawing.Color.White
        Me.CLabel.Location = New System.Drawing.Point(146, 511)
        Me.CLabel.Name = "CLabel"
        Me.CLabel.Size = New System.Drawing.Size(54, 27)
        Me.CLabel.TabIndex = 20
        Me.CLabel.Text = "Cart"
        '
        'AULabel
        '
        Me.AULabel.AutoSize = True
        Me.AULabel.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AULabel.Location = New System.Drawing.Point(146, 615)
        Me.AULabel.Name = "AULabel"
        Me.AULabel.Size = New System.Drawing.Size(94, 27)
        Me.AULabel.TabIndex = 19
        Me.AULabel.Text = "Account"
        '
        'MCLabel
        '
        Me.MCLabel.AutoSize = True
        Me.MCLabel.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MCLabel.Location = New System.Drawing.Point(146, 187)
        Me.MCLabel.Name = "MCLabel"
        Me.MCLabel.Size = New System.Drawing.Size(137, 27)
        Me.MCLabel.TabIndex = 18
        Me.MCLabel.Text = "Main Course"
        '
        'PictureBox6
        '
        Me.PictureBox6.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox6.Image = Global.GAD_MP_1.My.Resources.Resources.poinsettia
        Me.PictureBox6.Location = New System.Drawing.Point(23, 261)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox6.TabIndex = 17
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox5.Image = Global.GAD_MP_1.My.Resources.Resources.ice_cream_cup
        Me.PictureBox5.Location = New System.Drawing.Point(22, 367)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox5.TabIndex = 16
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox4.Image = Global.GAD_MP_1.My.Resources.Resources.shopping_cart
        Me.PictureBox4.Location = New System.Drawing.Point(23, 473)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox4.TabIndex = 15
        Me.PictureBox4.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Transparent
        Me.PictureBox1.Image = Global.GAD_MP_1.My.Resources.Resources.iftar
        Me.PictureBox1.Location = New System.Drawing.Point(22, 155)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.Coral
        Me.Button2.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(183, 13)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(100, 50)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "Logout"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Coral
        Me.Button1.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(23, 13)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(99, 50)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Close"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'GAD_MP_Form1_Title
        '
        Me.GAD_MP_Form1_Title.AutoSize = True
        Me.GAD_MP_Form1_Title.Font = New System.Drawing.Font("Microsoft JhengHei UI", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GAD_MP_Form1_Title.Location = New System.Drawing.Point(12, 79)
        Me.GAD_MP_Form1_Title.Name = "GAD_MP_Form1_Title"
        Me.GAD_MP_Form1_Title.Size = New System.Drawing.Size(285, 61)
        Me.GAD_MP_Form1_Title.TabIndex = 0
        Me.GAD_MP_Form1_Title.Text = "FOOD HUB"
        '
        'ShapeContainer2
        '
        Me.ShapeContainer2.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer2.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer2.Name = "ShapeContainer2"
        Me.ShapeContainer2.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer2.Size = New System.Drawing.Size(307, 684)
        Me.ShapeContainer2.TabIndex = 24
        Me.ShapeContainer2.TabStop = False
        '
        'RectangleShape1
        '
        Me.RectangleShape1.Location = New System.Drawing.Point(12, 483)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(5, 99)
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft JhengHei", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(15, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(547, 47)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "All The Food That’s Fit to cart"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(307, -2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(959, 82)
        Me.Panel1.TabIndex = 5
        '
        'CartLBL1
        '
        Me.CartLBL1.AutoSize = True
        Me.CartLBL1.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CartLBL1.Location = New System.Drawing.Point(388, 124)
        Me.CartLBL1.Name = "CartLBL1"
        Me.CartLBL1.Size = New System.Drawing.Size(72, 27)
        Me.CartLBL1.TabIndex = 6
        Me.CartLBL1.Text = "Name"
        '
        'CartLBL2
        '
        Me.CartLBL2.AutoSize = True
        Me.CartLBL2.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CartLBL2.Location = New System.Drawing.Point(673, 124)
        Me.CartLBL2.Name = "CartLBL2"
        Me.CartLBL2.Size = New System.Drawing.Size(60, 27)
        Me.CartLBL2.TabIndex = 7
        Me.CartLBL2.Text = "Price"
        '
        'CartLBL3
        '
        Me.CartLBL3.AutoSize = True
        Me.CartLBL3.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CartLBL3.Location = New System.Drawing.Point(894, 124)
        Me.CartLBL3.Name = "CartLBL3"
        Me.CartLBL3.Size = New System.Drawing.Size(99, 27)
        Me.CartLBL3.TabIndex = 8
        Me.CartLBL3.Text = "Quantity"
        '
        'CartLBL4
        '
        Me.CartLBL4.AutoSize = True
        Me.CartLBL4.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CartLBL4.Location = New System.Drawing.Point(1090, 124)
        Me.CartLBL4.Name = "CartLBL4"
        Me.CartLBL4.Size = New System.Drawing.Size(60, 27)
        Me.CartLBL4.TabIndex = 9
        Me.CartLBL4.Text = "Type"
        '
        'ListBox1
        '
        Me.ListBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox1.Font = New System.Drawing.Font("Microsoft JhengHei", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 24
        Me.ListBox1.Location = New System.Drawing.Point(393, 185)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(264, 288)
        Me.ListBox1.TabIndex = 10
        '
        'ListBox2
        '
        Me.ListBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox2.Font = New System.Drawing.Font("Microsoft JhengHei", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 24
        Me.ListBox2.Location = New System.Drawing.Point(678, 177)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(145, 288)
        Me.ListBox2.TabIndex = 11
        '
        'ListBox3
        '
        Me.ListBox3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox3.Font = New System.Drawing.Font("Microsoft JhengHei", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.ItemHeight = 24
        Me.ListBox3.Location = New System.Drawing.Point(899, 177)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(94, 288)
        Me.ListBox3.TabIndex = 12
        '
        'ListBox4
        '
        Me.ListBox4.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.ListBox4.Font = New System.Drawing.Font("Microsoft JhengHei", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListBox4.FormattingEnabled = True
        Me.ListBox4.ItemHeight = 24
        Me.ListBox4.Location = New System.Drawing.Point(1095, 177)
        Me.ListBox4.Name = "ListBox4"
        Me.ListBox4.Size = New System.Drawing.Size(157, 288)
        Me.ListBox4.TabIndex = 13
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.Coral
        Me.Button3.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(1052, 590)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(200, 50)
        Me.Button3.TabIndex = 14
        Me.Button3.Text = "Check Out"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.PictureBox2)
        Me.Panel2.Controls.Add(Me.PictureBox7)
        Me.Panel2.Controls.Add(Me.PictureBox8)
        Me.Panel2.Controls.Add(Me.PictureBox9)
        Me.Panel2.Location = New System.Drawing.Point(307, 77)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(940, 583)
        Me.Panel2.TabIndex = 22
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(156, 516)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(212, 27)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Time to fill your cart!"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(230, 279)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(547, 27)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "🍤 Create 🍜  your 🥧  Custom 🍖 Food 🥩 Courses🍗"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(402, 61)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(351, 27)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "☁ Your Cart Feels A Little Light ☁"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft JhengHei", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(28, 199)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(178, 27)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Wow, so empty..."
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.GAD_MP_1.My.Resources.Resources.nothing_found_200px
        Me.PictureBox2.Location = New System.Drawing.Point(783, 91)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox2.TabIndex = 3
        Me.PictureBox2.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.GAD_MP_1.My.Resources.Resources.where_what_quest_200px
        Me.PictureBox7.Location = New System.Drawing.Point(634, 385)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox7.TabIndex = 2
        Me.PictureBox7.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = Global.GAD_MP_1.My.Resources.Resources.inbox_200px
        Me.PictureBox8.Location = New System.Drawing.Point(81, 298)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox8.TabIndex = 1
        Me.PictureBox8.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = Global.GAD_MP_1.My.Resources.Resources.image_not_available_200px
        Me.PictureBox9.Location = New System.Drawing.Point(245, 38)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(100, 100)
        Me.PictureBox9.TabIndex = 0
        Me.PictureBox9.TabStop = False
        '
        'GAD_MP_Form7_Cart
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1264, 681)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.ListBox4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.ListBox3)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.CartLBL4)
        Me.Controls.Add(Me.CartLBL3)
        Me.Controls.Add(Me.CartLBL2)
        Me.Controls.Add(Me.CartLBL1)
        Me.Controls.Add(Me.GAD_MP_Form1_Home_TitlePanel)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "GAD_MP_Form7_Cart"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "GAD_MP_Form7_Cart"
        Me.GAD_MP_Form1_Home_TitlePanel.ResumeLayout(False)
        Me.GAD_MP_Form1_Home_TitlePanel.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GAD_MP_Form1_Home_TitlePanel As System.Windows.Forms.Panel
    Friend WithEvents DLabel As System.Windows.Forms.Label
    Friend WithEvents ICLabel As System.Windows.Forms.Label
    Friend WithEvents CLabel As System.Windows.Forms.Label
    Friend WithEvents AULabel As System.Windows.Forms.Label
    Friend WithEvents MCLabel As System.Windows.Forms.Label
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents GAD_MP_Form1_Title As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents ShapeContainer2 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents CartLBL1 As System.Windows.Forms.Label
    Friend WithEvents CartLBL2 As System.Windows.Forms.Label
    Friend WithEvents CartLBL3 As System.Windows.Forms.Label
    Friend WithEvents CartLBL4 As System.Windows.Forms.Label
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox3 As System.Windows.Forms.ListBox
    Friend WithEvents ListBox4 As System.Windows.Forms.ListBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox8 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox9 As System.Windows.Forms.PictureBox
End Class
