﻿Public Class GAD_MP_COD

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label8.Text = "Thank You for Ordering , " & vbCrLf & "Your order will soon arrive on your doorstep"
    End Sub
End Class